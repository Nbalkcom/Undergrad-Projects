﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    private void Start()
    {
        //Text

        //Enemy Score Text
        if(GameObject.Find("EnemyScore") != null)
        {
            EnemyScore = GameObject.Find("EnemyScore");
            Enemyscore = EnemyScore.GetComponent<Text>();
            Enemyscore.text = "Guards defeated/ Grates destroyed: " + escore.ToString();
        }
        
        //Treasure Score Text
        if(GameObject.Find("TreasureScore") != null)
        {
            TreasureScore = GameObject.Find("TreasureScore");
            Treasurescore = TreasureScore.GetComponent<Text>();
            Treasurescore.text = "Treasures collected: " + tscore.ToString() + "/3";
        }
        
    }
    public static GameManager instance;
    public static GameManager Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<GameManager>();
            }

            return instance;
        }
    }
    public GameObject playerPrefab;
    public static int tscore = 0;
    public static int escore = 0;
    private int currentLevel;

    private GameObject EnemyScore;
    private GameObject TreasureScore;
    public GameObject pauseMenu;

    private Text Enemyscore;
    private Text Treasurescore;

    public enum GameState
    {
        ACTIVE, PAUSED
    }
    public GameState gameState;
    public void SwitchGameStateTo(GameState state)
    {
        Debug.Log("Game state is being changed");
        gameState = state;

        switch (state)
        {
            case GameState.ACTIVE:
                Time.timeScale = 1;
                //Hide pause objects
                pauseMenu.SetActive(false);
                break;
            case GameState.PAUSED:
                Time.timeScale = 0;
                //Show pause objects
                pauseMenu.SetActive(true);
                break;
        }
    }

    public void GameOver()
    {
        SceneManager.LoadScene("GameOver", LoadSceneMode.Single);
        
    }

    //For the buttons

    //Unpauses the game
    public void Unpause()
    {
        SwitchGameStateTo(GameState.ACTIVE);
    }

    //Loads First Scene
    public void StartGame()
    {
        SceneManager.LoadScene("Test Level", LoadSceneMode.Single);
    }

    //Loads Main Menu Scene
    public void MainMenu()
    {
        SceneManager.LoadScene("Main Menu", LoadSceneMode.Single);
        SwitchGameStateTo(GameState.ACTIVE);
    }

    // Reloads test scene
    public void ReloadScene()
    {
        currentLevel = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentLevel, LoadSceneMode.Single);
    }
    //Exits game application
    public void ExitGame()
    {
        Application.Quit();
    }

    
}
