﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Checkpoint : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D collision)

    {

        if (!collision.isTrigger) //Check if the detected collider is not a trigger.

        {

            if (collision.GetComponent<Player>()) //Check if the detected collider has the Player component.

            {

                int CPLevel = SceneManager.GetActiveScene().buildIndex;

                Destroy(gameObject); //Destroy this checkpoint object since the player discovered it.

            }

        }

    }
}
