﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Treasure : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    public void OnTriggerEnter2D(Collider2D other)

    {

        if (!other.isTrigger)

        {

            if (other.gameObject.GetComponent<Interactor>())

            {
                if (GameObject.FindGameObjectWithTag("Treasure"))
                {
                    int gettscore = GameManager.tscore;
                    int newtscore = gettscore + 1;
                    GameManager.tscore = newtscore;
                    Destroy(gameObject);
                }
                    
            }
        }
    }
}
