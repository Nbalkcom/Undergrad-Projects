﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interactor : MonoBehaviour {

    public List<Interactable> nearbyInteractables;
    public float interactorRange = 10; //The max range at which I can interact with things.

    public List<Interactable.Key> keys;

    public bool HasKey(Interactable.Key key)
    {
        if(keys.Count == 0) { return false; } //If I have no keys, return false.

        for(int i = 0; i < keys.Count; i++) //Loop through my keys to see if I have one that matches the interactable's key requirement.
        {
            if (keys[i] == key)
            {
                keys.RemoveAt(i); //Remove the key.
                return true;
            }  
        }

        return false;
    }

    public void Update()
    {
        if(gameObject.tag == "Player")
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                Debug.Log("Player is pressing E key");
                InteractWithNearbyInteractables();
            }

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Debug.Log("Player is pressing Esc key");

                if (GameManager.Instance.gameState == GameManager.GameState.ACTIVE)
                    GameManager.Instance.SwitchGameStateTo(GameManager.GameState.PAUSED);
                else if (GameManager.Instance.gameState == GameManager.GameState.PAUSED)
                    GameManager.Instance.SwitchGameStateTo(GameManager.GameState.ACTIVE);
            }
            else if (Input.GetKeyDown(KeyCode.P))
            {
                Debug.Log("Player is pressing P key");

                GameManager.Instance.SwitchGameStateTo(GameManager.GameState.ACTIVE);
            }
        }
    }
    public void OnTriggerEnter2D(Collider2D collider)
    {
        
        if (!collider.isTrigger)
        {
            if (collider.GetComponent<Enemy>())
            {
                Debug.Log("Enemy found");
            }
            if (collider.GetComponent<HideItem>())
            {
                Debug.Log("Grate found");
            }
        }
    }

    public void InteractWithNearbyInteractables()
    {
        if(nearbyInteractables.Count == 0) { return; } //Exits the function if no nearby interactables are found.

        Interactable closestInteractable = null;

        for(int i = 0; i < nearbyInteractables.Count; i++)
        {
            if (nearbyInteractables[i] == null) //If the nearby interactable is destroyed or no longer there, remove it from the list and try again.
            {
                nearbyInteractables.RemoveAt(i);
                InteractWithNearbyInteractables();
                break;
            }

            if (Vector2.Distance(nearbyInteractables[i].transform.position, transform.position) < interactorRange || closestInteractable == null)
                closestInteractable = nearbyInteractables[i]; //Found the closest interactable object.

        }

        if(closestInteractable != null)
        {
            Debug.Log("Interacted with " + closestInteractable);
            closestInteractable.OnInteract(this); //Interact with the closest interactable.
        }
    }
}
