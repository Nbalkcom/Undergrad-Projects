﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 6f;

    Vector3 movement;
    Rigidbody2D playerRigidbody;
    

    // Start is called before the first frame update
    void Awake()
    {
        playerRigidbody = GetComponent<Rigidbody2D>();
        GetComponent<SpriteRenderer>().color = Color.blue;
    }

    // Update is called once per frame
    private void FixedUpdate()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");

        Move(h, v);
    }

    void Move(float h, float v)
    {
        movement.Set(h, v, 0f);

        movement = movement.normalized * speed * Time.deltaTime;

        if(h != 10f || h != -10f)
        {
            playerRigidbody.MovePosition(transform.position + movement);
        }
        
    }

    
}
