﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class Interactable : MonoBehaviour {

    public bool useable = true;
    public bool locked = false;
    public bool limitedUses = false; //Limits number of times this can be interacted with.
    public int uses = 1; //If limitedUses is turned on, this is how many times I may be interacted with
    public enum Key
    {
        None, Copper, Silver, Gold
    }
    public Key requiredKey = Key.None; //Optional key access
    public float interactionRange = 3; //Distance to interact
    public float timer;
    private int defaultUses;
   

    public void OnInteract(Interactor user)
    {
        if (CheckIsUseableBy(user))
        {
            InteractableAction(user);  
        }
        else
        {
            //If you have a UI element set up for displaying text, here is where you could call text such as "Locked" to it.
        }
    }

    public void OnTriggerEnter2D(Collider2D collider)
    {
        
        if(!collider.isTrigger)
        {
            if(collider.GetComponent<Interactor>())
            {
                Interactor interactor = collider.GetComponent<Interactor>();
                if(!interactor.nearbyInteractables.Contains(this))
                    interactor.nearbyInteractables.Add(this); //If the player's nearbyInteractables list doesn't already contain this interactable, add it to the list.
            }
        }
    }

    public void OnTriggerExit2D(Collider2D collider)
    {
        if (!collider.isTrigger)
        {
            if (collider.GetComponent<Interactor>())
            {
                Interactor interactor = collider.GetComponent<Interactor>();
                if (interactor.nearbyInteractables.Contains(this))
                    interactor.nearbyInteractables.Remove(this); //If the player's nearbyInteractables list contains this interactable, remove it from the list.
            }
        }
    }

    public bool CheckIsUseableBy(Interactor user)
    {
        if(Vector2.Distance(transform.position, user.transform.position) > interactionRange)
        {
            //Here's where you could code a message such as "Too far away" to be displayed to the UI.
            return false;
        }

        if (limitedUses)
        {
            if (uses > 0)
            {
                if (uses <= 0)
                {
                    //Here's where you could code a message such as "Already used" to be displayed to the UI.
                    return false;
                }
                    
            }
        }

        if (requiredKey != Key.None)
        {
            if(user.HasKey(requiredKey))
            {
                InteractableAction(user);
                return true;
            }
            else
            {
                //Here's where you could code a message such as "Requires ___ key" to be displayed to the UI.
            }
        }
        else
        {
            InteractableAction(user);
        }

        return false;
    }

    public virtual void InteractableAction(Interactor user)
    {
        if(limitedUses)
            uses--; //If this interactable has limited uses, decrement uses

        //Add whatever code here for what you would like to happen, such as increasing player score and/or destroying this gameobject.

        if (GameObject.FindGameObjectWithTag("Enemy"))
        {
            int getescore = GameManager.escore;
            int newescore = getescore + 1;
            GameManager.escore = newescore;
            Destroy(gameObject);
        }
            
        if (GameObject.FindGameObjectWithTag("HideSpot"))
            Destroy(gameObject);
    }
}
