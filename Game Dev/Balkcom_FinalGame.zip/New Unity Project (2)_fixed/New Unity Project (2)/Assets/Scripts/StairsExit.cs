﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StairsExit : MonoBehaviour
{
    

    public void OnTriggerEnter2D(Collider2D collider)
    {
        Debug.Log("Trigger entered");
        if (!collider.isTrigger)
        {
            if (collider.GetComponent<Interactor>())
            {
                int currentLevel = SceneManager.GetActiveScene().buildIndex;
                SceneManager.LoadScene(currentLevel+1, LoadSceneMode.Single);
                // Make it load new scenes

            }
        }
    }
}
