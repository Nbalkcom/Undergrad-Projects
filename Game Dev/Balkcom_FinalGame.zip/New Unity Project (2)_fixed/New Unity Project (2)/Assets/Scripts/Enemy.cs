﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    public void OnTriggerEnter2D(Collider2D other)

    {

        if (!other.isTrigger)

        {

            if (other.gameObject.GetComponent<Interactor>())

            {

                Interactor interactor = other.gameObject.GetComponent<Interactor>();

                //Add whatever code to affect your interactor here

            }

            if(other.gameObject.GetComponent<SpriteRenderer>())

{

                SpriteRenderer sr = other.gameObject.GetComponent<SpriteRenderer>();

                sr.color = Color.black;

                //Add whatever other code to affect your sprite renderer here

            }

        }

    }
    public void OnTriggerExit2D(Collider2D other)

    {

        if (!other.isTrigger)

        {

            if (other.gameObject.GetComponent<Interactor>())

            {

                Interactor interactor = other.gameObject.GetComponent<Interactor>();

                //Add whatever code to affect your interactor here

            }

            if(other.gameObject.GetComponent<SpriteRenderer>())

{

                SpriteRenderer sr = other.gameObject.GetComponent<SpriteRenderer>();

                sr.color = Color.blue;

                //Add whatever other code to affect your sprite renderer here

            }

        }

    }
}
